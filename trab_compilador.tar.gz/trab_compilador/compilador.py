import gi
import string

def posfixa (button):
    etiqueta_resultado = builder.get_object("etiqueta_resultado")
    entrada_infixa = builder.get_object("entrada_infixa")

    infixa = string(entrada_infixa.get_text())

    etiqueta_resultado.set_text(str(infixa))

builder  = Gtk.Builder()
builder.add_from_file("compilador.glade")
handlers = {
    "terminar_aplicacion": Gtk.main_quit,
    "converter_expressao": posfixa
    }

builder.connect_signals(handlers)
window = builder.get_object("janela_principal")
window.show_all()

Gtk.main()
